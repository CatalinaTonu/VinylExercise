package com.example.workshops2session2.ViewModel;

public class User {
    public static String name;
}
